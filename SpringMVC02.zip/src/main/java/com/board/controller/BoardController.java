package com.board.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.ibatis.annotations.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.board.entity.Board;
import com.board.mapper.BoardMapper;

// Handler(controller-POJO) Mapping이 controller를 찾기위해 @Controller로 명시해야 함
@Controller
public class BoardController {
	
	@Autowired
	private BoardMapper boardMapper;
	
	// main.jsp로 이동하는 동기방식 메소드
	@RequestMapping("/")
	public String main() {
		return "main";
	}

	/*
	 * //게시글 전체조회하기 /boardSelectList.do // @ResponseBody -> 비동기방식으로 요청이 되어서 사용하는 것이기
	 * 때문에 무조건 명시해줘야 함. // JSON 형태로 뿌려줌
	 * 
	 * @RequestMapping("/boardSelectList.do") public @ResponseBody List <Board>
	 * boardSelectList(){ System.out.println("[게시글 전체조회]"); List<Board> list =
	 * boardMapper.boardSelectList(); return list;
	 * 
	 * } // 게시글 등록
	 * 
	 * @PostMapping("/boardInsert.do") public @ResponseBody void boardInsert(Board
	 * board) { boardMapper.boardInsert(board); } // 게시글 삭제
	 * 
	 * @GetMapping("/boardDelet.do") public @ResponseBody void
	 * boardDelete(@RequestParam("idx") int idx) { boardMapper.boardDelete(idx); }
	 * // 게시글 조회수
	 * 
	 * @GetMapping("/boardCount.do") public @ResponseBody void
	 * boardCount(@RequestParam("idx") int idx) { boardMapper.boardCount(idx); } //
	 * 게시글 수정
	 * 
	 * @PostMapping("/boardUpdate.do") public @ResponseBody void boardUpdate(Board
	 * board) { boardMapper.boardUpdate(board); } // 게시글 상세보기에서 content내용 넣기
	 * 
	 * @GetMapping("/boardContent.do") public @ResponseBody Board
	 * boardContent(@RequestParam("idx") int idx) { Board board =
	 * boardMapper.boardContent(idx); return board; }
	 */
}