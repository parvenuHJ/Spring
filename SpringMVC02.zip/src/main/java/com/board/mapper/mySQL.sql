-- Board 게시판 테이블 생성
create table board(
	idx int not null auto_increment,
	title varchar(100) not null,
	content varchar(2000) not null,
	writer varchar(100) not null,
	indate datetime default now(),
	count int default 0,
	primary key(idx)
);


-- test 데이터 넣기
insert into board(title, content, writer)
values('스마트', '인재', '개발원');
insert into board(title, content, writer)
values('도레미', '파솔', '라시도');
insert into board(title, content, writer)
values('가나다', '라마바사', '아자차카');

-- 값 조회하기 alt+x
select *
from board;